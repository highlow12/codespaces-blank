# Planning note 87

This is synthetic offline demonstration content for the Planning cluster.
