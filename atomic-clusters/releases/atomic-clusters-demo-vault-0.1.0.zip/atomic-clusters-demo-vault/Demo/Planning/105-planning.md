# Planning note 105

This is synthetic offline demonstration content for the Planning cluster.
