# Planning note 93

This is synthetic offline demonstration content for the Planning cluster.
