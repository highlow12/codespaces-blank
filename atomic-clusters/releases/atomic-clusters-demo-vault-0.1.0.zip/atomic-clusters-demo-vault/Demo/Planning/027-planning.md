# Planning note 27

This is synthetic offline demonstration content for the Planning cluster.
