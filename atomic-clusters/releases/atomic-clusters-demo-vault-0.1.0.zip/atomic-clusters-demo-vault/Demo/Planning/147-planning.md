# Planning note 147

This is synthetic offline demonstration content for the Planning cluster.
