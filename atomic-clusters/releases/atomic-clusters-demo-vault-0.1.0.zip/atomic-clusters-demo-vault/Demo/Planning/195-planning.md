# Planning note 195

This is synthetic offline demonstration content for the Planning cluster.
