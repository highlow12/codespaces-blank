# Planning note 3

This is synthetic offline demonstration content for the Planning cluster.
