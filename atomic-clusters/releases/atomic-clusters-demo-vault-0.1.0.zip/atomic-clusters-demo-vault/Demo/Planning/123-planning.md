# Planning note 123

This is synthetic offline demonstration content for the Planning cluster.
