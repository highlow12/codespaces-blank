# Planning note 213

This is synthetic offline demonstration content for the Planning cluster.
