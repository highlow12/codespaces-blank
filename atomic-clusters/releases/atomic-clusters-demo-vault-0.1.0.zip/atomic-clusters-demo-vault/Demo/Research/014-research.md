# Research note 14

This is synthetic offline demonstration content for the Research cluster.
