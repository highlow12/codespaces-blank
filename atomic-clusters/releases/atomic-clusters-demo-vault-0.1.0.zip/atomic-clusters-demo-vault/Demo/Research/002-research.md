# Research note 2

This is synthetic offline demonstration content for the Research cluster.
