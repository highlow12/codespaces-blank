# Research note 8

This is synthetic offline demonstration content for the Research cluster.
