# Research note 26

This is synthetic offline demonstration content for the Research cluster.
