# Research note 20

This is synthetic offline demonstration content for the Research cluster.
