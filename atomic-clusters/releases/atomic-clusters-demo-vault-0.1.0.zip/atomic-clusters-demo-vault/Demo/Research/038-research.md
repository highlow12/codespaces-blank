# Research note 38

This is synthetic offline demonstration content for the Research cluster.
