# Research note 188

This is synthetic offline demonstration content for the Research cluster.
