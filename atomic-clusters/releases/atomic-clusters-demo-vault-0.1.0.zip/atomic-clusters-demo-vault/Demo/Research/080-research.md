# Research note 80

This is synthetic offline demonstration content for the Research cluster.
