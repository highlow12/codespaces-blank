# Research note 98

This is synthetic offline demonstration content for the Research cluster.
