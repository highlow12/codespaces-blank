# Architecture note 97

This is synthetic offline demonstration content for the Architecture cluster.
