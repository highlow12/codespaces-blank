# Architecture note 37

This is synthetic offline demonstration content for the Architecture cluster.
