# Architecture note 13

This is synthetic offline demonstration content for the Architecture cluster.
