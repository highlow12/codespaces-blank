# Architecture note 1

This is synthetic offline demonstration content for the Architecture cluster.
