# Learning note 5

This is synthetic offline demonstration content for the Learning cluster.
