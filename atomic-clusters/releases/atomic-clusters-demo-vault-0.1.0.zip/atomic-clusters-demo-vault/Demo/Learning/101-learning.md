# Learning note 101

This is synthetic offline demonstration content for the Learning cluster.
