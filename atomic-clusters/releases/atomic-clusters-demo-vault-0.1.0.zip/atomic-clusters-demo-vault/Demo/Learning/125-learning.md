# Learning note 125

This is synthetic offline demonstration content for the Learning cluster.
