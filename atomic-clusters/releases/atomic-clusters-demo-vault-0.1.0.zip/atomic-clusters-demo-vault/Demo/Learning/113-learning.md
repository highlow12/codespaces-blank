# Learning note 113

This is synthetic offline demonstration content for the Learning cluster.
