# Learning note 47

This is synthetic offline demonstration content for the Learning cluster.
