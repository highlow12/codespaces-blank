# Learning note 107

This is synthetic offline demonstration content for the Learning cluster.
