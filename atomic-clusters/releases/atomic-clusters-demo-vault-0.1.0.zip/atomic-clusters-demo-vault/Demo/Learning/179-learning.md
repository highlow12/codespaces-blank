# Learning note 179

This is synthetic offline demonstration content for the Learning cluster.
