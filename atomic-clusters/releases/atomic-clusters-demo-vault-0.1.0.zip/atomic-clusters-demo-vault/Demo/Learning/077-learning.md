# Learning note 77

This is synthetic offline demonstration content for the Learning cluster.
