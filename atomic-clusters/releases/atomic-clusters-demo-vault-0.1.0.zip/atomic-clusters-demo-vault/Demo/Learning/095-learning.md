# Learning note 95

This is synthetic offline demonstration content for the Learning cluster.
