# Learning note 17

This is synthetic offline demonstration content for the Learning cluster.
