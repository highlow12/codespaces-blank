# Learning note 23

This is synthetic offline demonstration content for the Learning cluster.
