# Learning note 119

This is synthetic offline demonstration content for the Learning cluster.
