# Learning note 29

This is synthetic offline demonstration content for the Learning cluster.
