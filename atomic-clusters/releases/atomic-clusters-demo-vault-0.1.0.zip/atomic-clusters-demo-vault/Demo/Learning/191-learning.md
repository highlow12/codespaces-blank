# Learning note 191

This is synthetic offline demonstration content for the Learning cluster.
