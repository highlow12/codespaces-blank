# Learning note 71

This is synthetic offline demonstration content for the Learning cluster.
