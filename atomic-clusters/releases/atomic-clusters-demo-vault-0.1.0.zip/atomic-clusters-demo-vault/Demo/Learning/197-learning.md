# Learning note 197

This is synthetic offline demonstration content for the Learning cluster.
