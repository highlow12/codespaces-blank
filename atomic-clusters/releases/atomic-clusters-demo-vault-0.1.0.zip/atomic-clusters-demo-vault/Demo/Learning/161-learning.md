# Learning note 161

This is synthetic offline demonstration content for the Learning cluster.
