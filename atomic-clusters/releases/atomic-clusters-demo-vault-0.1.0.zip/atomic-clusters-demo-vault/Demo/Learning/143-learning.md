# Learning note 143

This is synthetic offline demonstration content for the Learning cluster.
