# Learning note 167

This is synthetic offline demonstration content for the Learning cluster.
