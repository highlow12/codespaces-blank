# Learning note 173

This is synthetic offline demonstration content for the Learning cluster.
