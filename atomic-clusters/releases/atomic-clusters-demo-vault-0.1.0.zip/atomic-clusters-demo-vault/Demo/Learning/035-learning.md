# Learning note 35

This is synthetic offline demonstration content for the Learning cluster.
