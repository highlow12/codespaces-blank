# Learning note 11

This is synthetic offline demonstration content for the Learning cluster.
