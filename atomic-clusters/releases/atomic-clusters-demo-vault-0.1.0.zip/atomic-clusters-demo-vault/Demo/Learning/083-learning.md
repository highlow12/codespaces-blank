# Learning note 83

This is synthetic offline demonstration content for the Learning cluster.
