# Learning note 185

This is synthetic offline demonstration content for the Learning cluster.
