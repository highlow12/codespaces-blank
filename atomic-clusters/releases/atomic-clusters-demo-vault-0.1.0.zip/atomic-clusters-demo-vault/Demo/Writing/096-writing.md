# Writing note 96

This is synthetic offline demonstration content for the Writing cluster.
