# Writing note 120

This is synthetic offline demonstration content for the Writing cluster.
