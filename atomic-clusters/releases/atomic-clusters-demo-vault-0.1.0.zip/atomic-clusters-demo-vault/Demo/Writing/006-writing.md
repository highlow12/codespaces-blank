# Writing note 6

This is synthetic offline demonstration content for the Writing cluster.
