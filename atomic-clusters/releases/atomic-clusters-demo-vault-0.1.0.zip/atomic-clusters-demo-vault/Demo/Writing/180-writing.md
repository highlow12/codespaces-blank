# Writing note 180

This is synthetic offline demonstration content for the Writing cluster.
