# Writing note 18

This is synthetic offline demonstration content for the Writing cluster.
