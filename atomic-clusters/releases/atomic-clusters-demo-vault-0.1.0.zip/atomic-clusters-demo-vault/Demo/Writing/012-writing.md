# Writing note 12

This is synthetic offline demonstration content for the Writing cluster.
