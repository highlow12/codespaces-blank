# Writing note 36

This is synthetic offline demonstration content for the Writing cluster.
