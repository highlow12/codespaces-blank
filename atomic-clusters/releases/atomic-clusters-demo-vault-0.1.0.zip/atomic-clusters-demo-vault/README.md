# Atomic Clusters demo vault

This vault contains 240 synthetic notes, their synthetic embeddings, and a completed Atomic Clusters result. Open it as an Obsidian vault and run **Open cluster explorer**. No API key or source note data is included.
